package negocio;

import basicas.Usuario;

public class Fachada {

	
private static Fachada instancia;
	
	private CadastroUsuario cadastroUsuario;
	private CadastroCompra cadastroCompra;
	private CadastroLivro cadastroLivro;
	private CadastroAutor cadastroAutor;
	
	private Fachada(){
		this.cadastroUsuario = new CadastroUsuario();
		this.cadastroCompra = new CadastroCompra();
		this.cadastroLivro = new CadastroLivro();
		this.cadastroAutor = new CadastroAutor();
	}
	
	public static Fachada obterInstancia() {
		
		if (instancia == null) {
			instancia = new Fachada();
		}

		return instancia;
		
	}	
	

	//USUARIO
	public void cadastrarUsuario(Usuario usuario) {
		cadastroUsuario.cadastrar(usuario);
	}

	public void buscarUsuario(Usuario usuario) {
		cadastroUsuario.buscar(usuario);
	}
	
	public void atualizarUsuario(Usuario usuario) {
		cadastroUsuario.atualizar(usuario);
	}
	
	public void removerUsuario(Usuario usuario) {
		cadastroUsuario.remover(usuario);
	}

	
	//LIVRO



}
