package negocio;

public class CadastroAutor {

}
