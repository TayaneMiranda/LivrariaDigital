package negocio;

public class CadastroLivro {

}
