package negocio;

import basicas.Usuario;
import dados.RepositorioUsuario;

public class CadastroUsuario {

	
	private RepositorioUsuario repoUsuario;
	
	public CadastroUsuario(){
		this.repoUsuario = new RepositorioUsuario();
	}
	
	public CadastroUsuario(RepositorioUsuario repo){
		this.repoUsuario = repo;
	}
	
	
	public void cadastrar(Usuario user) {
		//FAZER
	}

	public void remover(Usuario user) {
		//FAZER
	}

	public void buscar(Usuario user) {
		//FAZER
	}
	
	public void atualizar(Usuario user) {
		//FAZER
	}
	
}
