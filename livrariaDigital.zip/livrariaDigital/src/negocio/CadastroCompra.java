package negocio;

public class CadastroCompra {

}
