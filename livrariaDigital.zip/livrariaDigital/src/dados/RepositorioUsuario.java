package dados;

public class RepositorioUsuario {

}
