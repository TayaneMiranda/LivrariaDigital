package dados;

public class Fachada {

}
