package dados;

public class RepositorioUsuarios {

}
