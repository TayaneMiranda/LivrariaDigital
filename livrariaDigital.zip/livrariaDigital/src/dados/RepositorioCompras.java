package dados;

import negocio.Compra;

public class RepositorioCompras {
	
	private final static int TAM_MAX = 200;
	
	private Compra[] compras;
	private int proxima;
	
	
	
	public RepositorioCompras(){
		this.compras = new Compra[TAM_MAX];
		this.proxima = 0;
	}
	
	
	public RepositorioCompras(int tamanho) {
		this.compras = new Compra[tamanho];
		this.proxima = 0;
	}
	
	
	
	private int retornarPosicao(String numero) {

		if (numero == null) {
			return -1;
		}
		
		for (int i = 0; i< this.proxima; i++){
			if (numero.equals( compras[i].getNumeroCompra() ) ) {
				return i;
			} 
		}
		
		return -1;
	}
	
	
public Compra buscarCompra(String numero) {
		
		int posicao = this.retornarPosicao(numero);
		
		return (posicao != -1) ? this.compras[posicao] : null; 
	}
	
	public boolean existe(String numero) {
		return this.retornarPosicao(numero) != -1;
	}
	

	
public void atualizarCompra(Compra compraAtualizada) {
		
		if (compraAtualizada == null) {
			System.out.println("Compra invalida!");
			return;
		}
		
		int posicaoCompraAserAtualizada = this.retornarPosicao(compraAtualizada.getNumeroCompra());
		if (posicaoCompraAserAtualizada == -1) {
			System.out.println("Compra inexistente, numero: " + compraAtualizada.getNumeroCompra());
			return;
		}
		this.compras[posicaoCompraAserAtualizada] = compraAtualizada;
	}
	
	
	
	
	
	
	
	
}
